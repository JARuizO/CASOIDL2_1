﻿namespace WebApplicationIDL2.Controllers.Entidades
{
    public class Autor
    {
     
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
